<template>
  <div>
    <h1>Home</h1>
    <p>Here is some information. This is the home page</p>
  </div>
</template>

<script>
export default {
  name: 'Home' //this is the name of the component
}
</script>
<style>

</style>
