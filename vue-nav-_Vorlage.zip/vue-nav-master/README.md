This is an example of how to create a navigation bar that gets the links and router names from the component.

Tutorial is on [Medium](https://medium.com/@maeganwilson_/how-to-create-a-navigation-bar-in-vue-js-8a70e7f29f80)
